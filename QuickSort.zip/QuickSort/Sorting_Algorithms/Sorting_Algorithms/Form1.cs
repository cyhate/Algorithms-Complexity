﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sorting_Algorithms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        int NumberofNumbers;
        int[] UnsortedNumbers;

        private void button1_Click(object sender, EventArgs e)
        {
            
            Random A = new Random();

            NumberofNumbers = (int)numericUpDown1.Value;
            UnsortedNumbers = new int[NumberofNumbers];

            textBox1.Text = "";

            for (int i=0; i< NumberofNumbers; i++)
            {

                UnsortedNumbers[i] = A.Next(90000); //90000 einai o megistos arithos pou tha paraxthe
                textBox1.Text += UnsortedNumbers[i].ToString() + "\t";

            }


        }

        private void button2_Click_1(object sender, EventArgs e)
        {

            textBox3.Text = "";
            int Steps = 0;
            int theoSteps = 0;


                static void quicksort(int[] UnsortedNumbers, int left, int right)
                {
                    if (left < right)
                    {
                        int pivot = partition(UnsortedNumbers, left, right);
                        quicksort(UnsortedNumbers, left, pivot - 1);
                        quicksort(UnsortedNumbers, pivot + 1, right);
                    }
                }

                static int partition(int[] UnsortedNumbers, int left, int right)
                {
                    int i = left;
                    int pivot = UnsortedNumbers[right];
                    int temp;

                    for (int ia = left; ia <= right; ia++)
                    {
                        if (UnsortedNumbers[ia] < pivot)
                        {
                            temp = UnsortedNumbers[i];
                            UnsortedNumbers[i] = UnsortedNumbers[ia];
                            UnsortedNumbers[ia] = temp;
                            i++;
                        }
                    }

                    temp = UnsortedNumbers[right];
                    UnsortedNumbers[right] = UnsortedNumbers[i];
                    UnsortedNumbers[i] = temp;
                    return i;
                }

                textBox2.Text = "";
            for (int i = 0; i < NumberofNumbers; i++)
            {

               
                textBox2.Text += UnsortedNumbers[i].ToString() + "\t";

            }

            textBox3.Text = Steps.ToString();
            textBox4.Text = theoSteps.ToString();
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
